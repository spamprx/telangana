"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { districts } from "@/lib/districts"

export function DistrictMap() {
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null)

  const handleDistrictClick = (districtSlug: string) => {
    setSelectedDistrict(districtSlug)
  }

  const selectedDistrictData = selectedDistrict ? districts.find((d) => d.slug === selectedDistrict) : null

  return (
    <div className="relative bg-white rounded-lg shadow-md p-4">
      <div className="relative h-[600px] w-full">
        <Image
          // src="/telangana-map.png"
          src="/dummy-image.jpg" // Using dummy image
          alt="Telangana Map with Districts"
          fill
          className="object-contain"
          useMap="#telangana-map"
        />

        {/* This would be an image map with clickable areas for each district */}
        <map name="telangana-map">
          {districts.map((district) => (
            <area
              key={district.slug}
              shape="poly"
              coords={district.mapCoords}
              alt={district.name}
              onClick={() => handleDistrictClick(district.slug)}
              style={{ cursor: "pointer" }}
            />
          ))}
        </map>

        {/* Fallback clickable districts for demo purposes */}
        <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-0">
          {districts.slice(0, 9).map((district) => (
            <div
              key={district.slug}
              className="border border-transparent hover:border-orange-500 cursor-pointer"
              onClick={() => handleDistrictClick(district.slug)}
            />
          ))}
        </div>
      </div>

      <Dialog open={!!selectedDistrict} onOpenChange={(open: boolean) => !open && setSelectedDistrict(null)}>
        <DialogContent className="sm:max-w-[500px]">
          {selectedDistrictData && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedDistrictData.name} District</DialogTitle>
                <DialogDescription>{selectedDistrictData.description.substring(0, 100)}...</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="relative h-[200px] w-full rounded-md overflow-hidden">
                  <Image
                    src={selectedDistrictData.coverImage || "/placeholder.svg"}
                    alt={selectedDistrictData.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-medium mb-2">Major Issues:</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    {selectedDistrictData.issues.slice(0, 2).map((issue, index) => (
                      <li key={index} className="text-sm">
                        {issue}
                      </li>
                    ))}
                  </ul>
                </div>
                <Button asChild>
                  <Link href={`/districts/${selectedDistrictData.slug}`}>View Full Details</Link>
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
