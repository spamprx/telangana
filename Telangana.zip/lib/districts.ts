export interface District {
  id: number
  slug: string
  name: string
  description: string
  population: string
  area: string
  headquarters: string
  majorTowns: string[]
  issues: string[]
  initiatives: string[]
  coverImage: string
  mapImage: string
  thumbnail: string
  mapCoords: string // For image map
}

export const districts: District[] = [
  {
    id: 1,
    slug: "hyderabad",
    name: "Hyderabad",
    description:
      "Hyderabad is the capital and largest city of Telangana. Known for its rich history, culture, and IT industry, it's a major urban center in South India. The city is home to many historical monuments like Charminar, Golconda Fort, and modern tech parks.",
    population: "10.5 million",
    area: "650 sq km",
    headquarters: "Hyderabad",
    majorTowns: ["Secunderabad", "Kukatpally", "Gachibowli", "Uppal"],
    issues: [
      "Urban congestion and traffic management",
      "Water scarcity in certain areas",
      "Air pollution concerns",
      "Housing affordability",
    ],
    initiatives: [
      "Hyderabad Metro Rail project for improved public transportation",
      "IT corridor development to boost tech industry",
      "Lake restoration projects to improve water bodies",
      "Smart city initiatives for better urban management",
    ],
    // coverImage: "/districts/hyderabad-cover.jpg",
    // mapImage: "/districts/hyderabad-map.jpg",
    // thumbnail: "/districts/hyderabad-thumb.jpg",
    coverImage: "/dummy-image.jpg",
    mapImage: "/dummy-image.jpg",
    thumbnail: "/dummy-image.jpg",
    mapCoords: "120,150,180,200", // Placeholder coordinates
  },
  {
    id: 2,
    slug: "warangal",
    name: "Warangal",
    description:
      "Warangal is the second largest city in Telangana and served as the capital of the Kakatiya dynasty. It's known for its historical monuments, temples, and educational institutions. The district has a rich cultural heritage and is an important educational hub.",
    population: "1.2 million",
    area: "1,235 sq km",
    headquarters: "Warangal",
    majorTowns: ["Hanamkonda", "Kazipet", "Jangaon", "Parkal"],
    issues: [
      "Infrastructure development needs",
      "Agricultural water management",
      "Rural healthcare access",
      "Educational quality improvements",
    ],
    initiatives: [
      "Heritage conservation of Warangal Fort and Thousand Pillar Temple",
      "Textile park development to boost local industry",
      "Rural road connectivity improvement",
      "Educational institution expansion",
    ],
    // coverImage: "/districts/warangal-cover.jpg",
    // mapImage: "/districts/warangal-map.jpg",
    // thumbnail: "/districts/warangal-thumb.jpg",
    coverImage: "/dummy-image.jpg",
    mapImage: "/dummy-image.jpg",
    thumbnail: "/dummy-image.jpg",
    mapCoords: "220,120,280,170", // Placeholder coordinates
  },
  {
    id: 3,
    slug: "karimnagar",
    name: "Karimnagar",
    description:
      "Karimnagar is known for its granite industry, agricultural production, and cultural heritage. The district is located in the northern part of Telangana and is an important agricultural and industrial center with significant irrigation projects.",
    population: "1 million",
    area: "2,128 sq km",
    headquarters: "Karimnagar",
    majorTowns: ["Huzurabad", "Jammikunta", "Sircilla", "Jagtial"],
    issues: [
      "Irrigation water management",
      "Granite industry environmental impact",
      "Rural employment opportunities",
      "Healthcare infrastructure",
    ],
    initiatives: [
      "Lower Manair Dam irrigation project expansion",
      "Granite industry regulation and modernization",
      "Rural skill development programs",
      "Healthcare facility upgrades in rural areas",
    ],
    // coverImage: "/districts/karimnagar-cover.jpg",
    // mapImage: "/districts/karimnagar-map.jpg",
    // thumbnail: "/districts/karimnagar-thumb.jpg",
    coverImage: "/dummy-image.jpg",
    mapImage: "/dummy-image.jpg",
    thumbnail: "/dummy-image.jpg",
    mapCoords: "180,80,240,130", // Placeholder coordinates
  },
  {
    id: 4,
    slug: "nizamabad",
    name: "Nizamabad",
    description:
      "Nizamabad is known for its agricultural production, particularly turmeric and rice. The district has a diverse cultural heritage with historical monuments and temples. It's an important commercial center in northern Telangana.",
    population: "1.8 million",
    area: "3,397 sq km",
    headquarters: "Nizamabad",
    majorTowns: ["Bodhan", "Armoor", "Balkonda", "Kamareddy"],
    issues: [
      "Agricultural market access for farmers",
      "Turmeric price fluctuations",
      "Irrigation infrastructure",
      "Rural education quality",
    ],
    initiatives: [
      "Turmeric processing and export promotion",
      "Irrigation canal network expansion",
      "Agricultural market reforms",
      "Rural school infrastructure improvement",
    ],
    // coverImage: "/districts/nizamabad-cover.jpg",
    // mapImage: "/districts/nizamabad-map.jpg",
    // thumbnail: "/districts/nizamabad-thumb.jpg",
    coverImage: "/dummy-image.jpg",
    mapImage: "/dummy-image.jpg",
    thumbnail: "/dummy-image.jpg",
    mapCoords: "140,60,200,110", // Placeholder coordinates
  },
  {
    id: 5,
    slug: "khammam",
    name: "Khammam",
    description:
      "Khammam is known for its agricultural production, forests, and mineral resources. The district has significant tribal populations and is rich in natural resources including coal deposits. It's an important agricultural and industrial center.",
    population: "1.4 million",
    area: "4,453 sq km",
    headquarters: "Khammam",
    majorTowns: ["Kothagudem", "Yellandu", "Sathupalli", "Madhira"],
    issues: [
      "Tribal community development",
      "Forest conservation and management",
      "Coal mining environmental impact",
      "Agricultural modernization",
    ],
    initiatives: [
      "Tribal welfare programs and education",
      "Sustainable forest management practices",
      "Mining regulation and worker safety",
      "Agricultural technology adoption programs",
    ],
    // coverImage: "/districts/khammam-cover.jpg",
    // mapImage: "/districts/khammam-map.jpg",
    // thumbnail: "/districts/khammam-thumb.jpg",
    coverImage: "/dummy-image.jpg",
    mapImage: "/dummy-image.jpg",
    thumbnail: "/dummy-image.jpg",
    mapCoords: "260,180,320,230", // Placeholder coordinates
  },
  // Additional districts would be added here
]

// For simplicity, we're adding 5 districts, but in a real application, all 33 would be included

export function getDistrictData(slug: string): District | undefined {
  return districts.find((district) => district.slug === slug)
}
